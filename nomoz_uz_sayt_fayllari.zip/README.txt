NOMOZ.UZ — sayt fayllari

1) index.html, style.css va script.js fayllarini bitta papkada saqlang.
2) index.html ni Chrome/Edge da oching.
3) Vaqtlarni o'zgartirib, Vaqtlarni saqlash tugmasini bosing.
4) Bildirishnomani yoqish tugmasiga bosib, brauzer ruxsatini bering.
5) Haqiqiy azon ovozi uchun o'zingizdagi MP3/audio faylni audio tanlash joyidan tanlang, keyin Eshitib ko'rish tugmasini bosing.

GitHub Pages:
Repository ga uch faylni yuklang -> Settings -> Pages -> Deploy from a branch -> main va /(root) -> Save.

Muhim: vaqtlar avtomatik hisoblanmaydi, foydalanuvchi o'zi kiritadi. Vaqtlar localStorage da shu brauzer qurilmasida saqlanadi. Bildirishnoma va vaqt tekshirish sahifa ochiq turganida ishlaydi. Sahifa yopilganda yoki telefon brauzeri to'xtatilganda azon/bildirishnomani kafolatlab bo'lmaydi; buning uchun PWA/service worker va qo'shimcha sozlash kerak. Audio fayl tanlash ham kerak, chunki bu paketga alohida azon MP3 kiritilmagan.
Namoz haqidagi qisqa matnlarni ishonchli ustoz yoki diniy manba bilan tekshiring.
